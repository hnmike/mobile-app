package com.example.appdocbao.trangcanhan;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.example.appdocbao.R;
import com.example.appdocbao.data.model.User;
import com.example.appdocbao.ui.profile.ProfileActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class thongtin extends AppCompatActivity {

    private Toolbar toolbar;
    private ImageView btnBack, ivAvatar;
    private TextView toolbarTitle, btnSave, tvChangePhoto;
    private EditText etUsername, etDisplayName, etEmail;
    private Button btnChangePassword;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private DocumentReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_thontintt);

        // Firebase setup
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        if (mAuth.getCurrentUser() != null) {
            userRef = db.collection("users").document(mAuth.getCurrentUser().getUid());
        } else {
            Toast.makeText(this, "Người dùng chưa đăng nhập!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Ánh xạ view
        toolbar = findViewById(R.id.toolbar);
        btnBack = findViewById(R.id.btnBack);
        ivAvatar = findViewById(R.id.ivAvatar); // avatar ảnh đại diện
        toolbarTitle = findViewById(R.id.toolbarTitle);
        btnSave = findViewById(R.id.btnSave);
        tvChangePhoto = findViewById(R.id.tvChangePhoto);
        etUsername = findViewById(R.id.etUsername);
        etDisplayName = findViewById(R.id.etDisplayName);
        etEmail = findViewById(R.id.etEmail);
        btnChangePassword = findViewById(R.id.btnChangePassword);
        progressBar = findViewById(R.id.progressBar);

        toolbarTitle.setText("Thông tin tài khoản");

        btnBack.setOnClickListener(view -> finish());

        btnSave.setOnClickListener(view -> saveUserInfo());

        tvChangePhoto.setOnClickListener(view ->
                Toast.makeText(this, "Tính năng đổi ảnh chưa hỗ trợ.", Toast.LENGTH_SHORT).show()
        );

        btnChangePassword.setOnClickListener(view ->{
            try {
                Intent intent = new Intent(thongtin.this, doimatkhau.class);
                startActivity(intent);
                Toast.makeText(this, "Chuyển đến doi mat khau", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e(TAG, "Error navigating to Account Info: " + e.getMessage());
                Toast.makeText(this, "Không thể mở trang doi mat khau", Toast.LENGTH_SHORT).show();
            }
                }


        );

        loadUserInfo();
    }

    private void loadUserInfo() {
        progressBar.setVisibility(View.VISIBLE);

        userRef.get().addOnSuccessListener(snapshot -> {
            progressBar.setVisibility(View.GONE);
            if (snapshot.exists()) {
                User user = snapshot.toObject(User.class);
                if (user != null) {
                    etUsername.setText(user.getUsername());
                    etDisplayName.setText(user.getDisplayName());
                    etEmail.setText(user.getEmail());
                    if (user.getPhotoUrl() != null && !user.getPhotoUrl().isEmpty()) {
                        Glide.with(this).load(user.getPhotoUrl()).into(ivAvatar);
                    }
                }
            } else {
                Toast.makeText(this, "Không tìm thấy dữ liệu người dùng!", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Lỗi khi tải thông tin: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private void saveUserInfo() {
        progressBar.setVisibility(View.VISIBLE);

        String username = etUsername.getText().toString().trim();
        String displayName = etDisplayName.getText().toString().trim();

        if (username.isEmpty() || displayName.isEmpty()) {
            Toast.makeText(this, "Vui lòng điền đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
            return;
        }

        userRef.update(
                "username", username,
                "displayName", displayName
        ).addOnSuccessListener(unused -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Đã lưu thông tin!", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(e -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this, "Lỗi khi lưu: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }
}
